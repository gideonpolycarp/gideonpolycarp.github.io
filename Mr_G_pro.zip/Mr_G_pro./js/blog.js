$(function () {
  /*$(".starter, .section").hide();*/
  
  $(window).scroll(function () {
    var pos = $("header").position();
    $(".navbar").css("background", "forestgreen");
    $(".navbar a").css("color", "white");
    /*$(".starter").fadeIn("slow");
    $(".section").fadeIn("6000");*/
  });
  alert("hhhjff");
  
  /*var pos = $("body").position();
  var height = "12px";
  if ( pos.top = height ){
    $(".navbar").css("background", "forestgreen");
  } else {
    $(".navbar").css("background", "transparent");
  }*/
});

