$(function () {
  $(".Article_img img").click(function () {
    $(".lightbox").css("opacity", "1"
  })
})

